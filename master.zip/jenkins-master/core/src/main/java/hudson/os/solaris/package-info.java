/**
 * Solaris specific features of Hudson.
 */
package hudson.os.solaris;