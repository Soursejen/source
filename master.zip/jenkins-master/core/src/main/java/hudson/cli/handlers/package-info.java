/**
 * {@link org.kohsuke.args4j.spi.OptionHandler} implementations for Hudson.
 */
package hudson.cli.handlers;

import org.kohsuke.args4j.spi.OptionHandler;