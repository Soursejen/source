Parts of the build scripts that are written in Groovy.

IntelliJ needs Groovy files to be in its source directory to provide completion and such,
so we need this to be in its own directory.